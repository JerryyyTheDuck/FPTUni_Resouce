/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ADMIN
 */
public class SpecCala extends Cala{
    private int color;
    
    public SpecCala(){
        color=0;
        
    }

    public SpecCala(int color, String owner, int price) {
        super(owner, price);
        this.color = color;
    }

    @Override
    public String toString() {
        return "SpecCala{" + "color=" + color + '}';
    }
    public void setData(){
       String name = getOwner();
       name.replace(name.substring(1, 1), "XX");
    }
}
